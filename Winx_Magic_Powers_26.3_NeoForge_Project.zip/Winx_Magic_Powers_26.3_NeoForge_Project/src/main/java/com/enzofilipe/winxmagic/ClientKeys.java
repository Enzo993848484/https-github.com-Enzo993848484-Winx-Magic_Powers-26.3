package com.enzofilipe.winxmagic;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

@EventBusSubscriber(modid = WinxMagicPowers.MOD_ID, value = Dist.CLIENT)
public final class ClientKeys {
    private static final KeyMapping.Category CATEGORY =
            new KeyMapping.Category(Identifier.fromNamespaceAndPath(WinxMagicPowers.MOD_ID, "powers"));

    private static final KeyMapping ENABLE =
            new KeyMapping("key.winx_magic_powers.enable", InputConstants.KEY_5, CATEGORY);
    private static final KeyMapping DISABLE =
            new KeyMapping("key.winx_magic_powers.disable", InputConstants.KEY_6, CATEGORY);

    private static final KeyMapping BLOOM =
            new KeyMapping("key.winx_magic_powers.bloom", InputConstants.KEY_B, CATEGORY);
    private static final KeyMapping STELLA =
            new KeyMapping("key.winx_magic_powers.stella", InputConstants.KEY_N, CATEGORY);
    private static final KeyMapping FLORA =
            new KeyMapping("key.winx_magic_powers.flora", InputConstants.KEY_K, CATEGORY);
    private static final KeyMapping MUSA =
            new KeyMapping("key.winx_magic_powers.musa", InputConstants.KEY_COMMA, CATEGORY);
    private static final KeyMapping TECNA =
            new KeyMapping("key.winx_magic_powers.tecna", InputConstants.KEY_PERIOD, CATEGORY);
    private static final KeyMapping AISHA =
            new KeyMapping("key.winx_magic_powers.aisha", InputConstants.KEY_Q, CATEGORY);

    private static boolean enabled = false;

    private ClientKeys() {
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.registerCategory(CATEGORY);
        event.register(ENABLE);
        event.register(DISABLE);
        event.register(BLOOM);
        event.register(STELLA);
        event.register(FLORA);
        event.register(MUSA);
        event.register(TECNA);
        event.register(AISHA);
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null || minecraft.screen != null) {
            return;
        }

        while (ENABLE.consumeClick()) {
            if (minecraft.hasShiftDown()) {
                enabled = true;
                show("§dPoderes Winx ativados!");
            }
        }

        while (DISABLE.consumeClick()) {
            if (minecraft.hasShiftDown()) {
                enabled = false;
                show("§7Poderes Winx desativados.");
            }
        }

        while (BLOOM.consumeClick()) sendPower(0, "Bloom");
        while (STELLA.consumeClick()) sendPower(1, "Stella");
        while (FLORA.consumeClick()) sendPower(2, "Flora");
        while (MUSA.consumeClick()) sendPower(3, "Musa");
        while (TECNA.consumeClick()) sendPower(4, "Tecna");
        while (AISHA.consumeClick()) sendPower(5, "Aisha");
    }

    private static void sendPower(int action, String name) {
        if (!enabled) {
            show("§cUse Shift + 5 para ativar os poderes.");
            return;
        }

        ClientPacketDistributor.sendToServer(new PowerPayload(action));
        show("§d" + name + " §f- poder ativado!");
    }

    private static void show(String text) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.displayClientMessage(Component.literal(text), true);
        }
    }
}
