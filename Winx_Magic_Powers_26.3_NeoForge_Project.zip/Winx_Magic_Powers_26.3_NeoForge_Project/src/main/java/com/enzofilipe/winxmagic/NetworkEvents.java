package com.enzofilipe.winxmagic;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

@EventBusSubscriber(modid = WinxMagicPowers.MOD_ID)
public final class NetworkEvents {
    private NetworkEvents() {
    }

    @SubscribeEvent
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("1")
                .playToServer(PowerPayload.TYPE, PowerPayload.STREAM_CODEC, NetworkEvents::handlePower);
    }

    private static void handlePower(PowerPayload payload, IPayloadContext context) {
        if (context.player() instanceof ServerPlayer player) {
            PowerLogic.apply(player, payload.action());
        }
    }
}
