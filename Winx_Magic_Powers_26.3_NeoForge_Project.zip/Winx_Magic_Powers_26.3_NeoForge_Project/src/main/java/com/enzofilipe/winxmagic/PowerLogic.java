package com.enzofilipe.winxmagic;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;

import java.util.List;

public final class PowerLogic {
    private PowerLogic() {
    }

    public static void apply(ServerPlayer player, int action) {
        switch (action) {
            case 0 -> bloom(player);
            case 1 -> stella(player);
            case 2 -> flora(player);
            case 3 -> musa(player);
            case 4 -> tecna(player);
            case 5 -> aisha(player);
            default -> {
            }
        }
    }

    private static List<Mob> hostileMobs(ServerPlayer player, double radius) {
        return player.level().getEntitiesOfClass(
                Mob.class,
                player.getBoundingBox().inflate(radius),
                mob -> mob.isAlive() && mob instanceof Enemy
        );
    }

    // Bloom: protege do fogo e incendeia mobs hostis próximos.
    private static void bloom(ServerPlayer player) {
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 20 * 12, 0));

        for (Mob mob : hostileMobs(player, 8.0)) {
            mob.igniteForSeconds(4.0F);
        }
    }

    // Stella: visão noturna temporária.
    private static void stella(ServerPlayer player) {
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 20 * 15, 0));
    }

    // Flora: raízes mágicas simuladas por lentidão forte nos inimigos.
    private static void flora(ServerPlayer player) {
        for (Mob mob : hostileMobs(player, 9.0)) {
            mob.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 20 * 6, 4));
        }
    }

    // Musa: onda sonora que empurra inimigos para longe.
    private static void musa(ServerPlayer player) {
        for (Mob mob : hostileMobs(player, 8.0)) {
            double dx = mob.getX() - player.getX();
            double dz = mob.getZ() - player.getZ();
            double length = Math.max(0.1, Math.sqrt(dx * dx + dz * dz));

            mob.setDeltaMovement(
                    mob.getDeltaMovement().add(
                            (dx / length) * 1.15,
                            0.30,
                            (dz / length) * 1.15
                    )
            );
        }
    }

    // Tecna: escudo temporário com resistência e absorção.
    private static void tecna(ServerPlayer player) {
        player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 20 * 15, 1));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 20 * 15, 1));
    }

    // Aisha: respiração aquática e apaga fogo do jogador.
    private static void aisha(ServerPlayer player) {
        player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 20 * 20, 0));
        player.clearFire();
    }
}
