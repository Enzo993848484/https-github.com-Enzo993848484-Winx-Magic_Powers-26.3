package com.enzofilipe.winxmagic;

import net.neoforged.fml.common.Mod;

@Mod(WinxMagicPowers.MOD_ID)
public final class WinxMagicPowers {
    public static final String MOD_ID = "winx_magic_powers";

    public WinxMagicPowers() {
    }
}
