package com.enzofilipe.winxmagic;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record PowerPayload(int action) implements CustomPacketPayload {
    public static final Type<PowerPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(WinxMagicPowers.MOD_ID, "use_power"));

    public static final StreamCodec<FriendlyByteBuf, PowerPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT,
            PowerPayload::action,
            PowerPayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
