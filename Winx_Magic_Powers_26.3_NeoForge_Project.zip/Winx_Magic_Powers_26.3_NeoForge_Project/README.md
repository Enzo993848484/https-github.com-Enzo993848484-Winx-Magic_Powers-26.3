# Winx Magic Powers 26.3 — NeoForge

Projeto fanmade para **Minecraft Java 26.3**, usando **NeoForge** e **Java 25**.

Não usa Fabric.

## Teclas

- `Shift + 5` — ativa os poderes
- `Shift + 6` — desativa os poderes
- `B` — Bloom
- `N` — Stella
- `K` — Flora
- `,` — Musa
- `.` — Tecna
- `Q` — Aisha

## Poderes desta versão

- Bloom: resistência ao fogo + incendeia mobs hostis próximos.
- Stella: visão noturna temporária.
- Flora: desacelera muito mobs hostis próximos.
- Musa: empurra mobs hostis para longe.
- Tecna: resistência + absorção temporária.
- Aisha: respiração aquática + apaga fogo do jogador.

## Como compilar no GitHub

1. Extraia este ZIP do projeto.
2. Envie **o conteúdo da pasta** para o repositório.
3. Abra a aba **Actions**.
4. Rode `Build NeoForge Mod` (ou faça um push na branch `main`).
5. Quando terminar, abra a execução e baixe o artefato `Winx-Magic-Powers-26.3`.
6. Dentro do artefato estará o `.jar` compilado.

O `.jar` final vai em:

`%appdata%\.minecraft\mods`

O `.jar` final **não deve ser extraído**.

## Observação

Este projeto usa código próprio e efeitos vanilla do Minecraft. Não inclui modelos, texturas, músicas ou outros arquivos oficiais de Winx.
